default['build-bl']['dest_path'] = "/tmp"
default['build-bl']['dest_name'] = "ROOT"