default['tomcat-component']['lib_uri'] = ""
default['tomcat-component']['war_uri'] = ""
default['tomcat-component']['create_context'] = true
default['tomcat-component']['war']['uri'] = ""
default['tomcat-component']['war']['appname'] = ""
default['tomcat-component']['context'] = nil

