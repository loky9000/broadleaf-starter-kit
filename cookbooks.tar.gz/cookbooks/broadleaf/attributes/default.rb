default["broadleaf"]["solr_url"] = ""
default["broadleaf"]["solr_reindex_url"] = ""
