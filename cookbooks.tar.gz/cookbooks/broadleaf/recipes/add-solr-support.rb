service "tomcat" do
  service_name "tomcat#{node["tomcat"]["base_version"]}"
  supports :restart => false, :status => true
  action :nothing
end

template "#{node['tomcat']['webapp_dir']}/ROOT/WEB-INF/applicationContext.xml" do
      owner node["tomcat"]["user"]
      group node["tomcat"]["group"]
      source "applicationContext.xml.erb"
      variables({
        :solr_url => node["broadleaf"]["solr_url"],
        :solr_reindex_url => node["broadleaf"]["solr_reindex_url"]
      })
      notifies :restart, "service[tomcat]", :delayed
    end

