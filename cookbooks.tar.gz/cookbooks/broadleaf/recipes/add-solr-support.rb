service "tomcat" do
  service_name "tomcat#{node["tomcat"]["base_version"]}"
  supports :restart => false, :status => true
  action :nothing
end

template "#{node['tomcat']['webapp_dir']}/#{app_name}.xml" do
      owner node["tomcat"]["user"]
      group node["tomcat"]["group"]
      source "context.xml.erb"
      variables({
        :context_attrs => node["tomcat-component"]["context"].to_hash.fetch("context_attrs", {}),
        :context_nodes => node["tomcat-component"]["context"].to_hash.fetch("context_nodes", [])
      })
      notifies :restart, "service[tomcat]", :delayed
    end

