default['build']['dest_path'] = "/tmp"
default['build']['dest_name'] = "ROOT"